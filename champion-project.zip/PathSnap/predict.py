"""Run the champion on one trip using its GPS, node and arc files."""
import argparse
from pathlib import Path

import numpy as np

from pathsnap.io import write_rows
from pathsnap.pipeline import MODEL_DIR, load_models, predict_indices, preprocess


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("track", "nodes", "arcs"):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--model", type=Path, default=MODEL_DIR)
    parser.add_argument("--output", type=Path, default=Path("predicted_arcs.csv"))
    args = parser.parse_args()
    track = np.loadtxt(args.track, dtype=float, ndmin=2)
    if len(track) < 2:
        parser.error("Route decoding requires at least two GPS observations.")
    nodes = np.loadtxt(args.nodes, dtype=float, ndmin=2)
    arcs = np.loadtxt(args.arcs, dtype=np.int32, ndmin=2)
    data = preprocess(track, nodes, arcs)
    selected = predict_indices(data, *load_models(args.model))
    predictions = data["candidates"][np.arange(len(selected)), selected]
    args.output.parent.mkdir(exist_ok=True, parents=True)
    write_rows(args.output, [
        dict(observation_index=i, timestamp=track[i, 2], predicted_arc_id=int(arc))
        for i, arc in enumerate(predictions)])
    print(f"Saved {len(predictions):,} arc predictions to {args.output}.")


if __name__ == "__main__":
    main()
