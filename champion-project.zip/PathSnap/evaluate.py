"""Evaluate the saved champion on prepared student-test trips."""
import argparse
import json
from pathlib import Path

import numpy as np

from pathsnap.io import load_prepared, write_rows
from pathsnap.metrics import evaluate
from pathsnap.pipeline import MODEL_DIR, load_models, predict_indices


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--prepared", type=Path, default=Path("prepared"))
    parser.add_argument("--model", type=Path, default=MODEL_DIR)
    parser.add_argument("--output", type=Path, default=Path("evaluation"))
    args = parser.parse_args()
    trips = sorted((args.prepared / "student_test").glob("*.npz"))
    if not trips:
        parser.error("No prepared student-test trips found.")
    models = load_models(args.model)
    rows = []
    for path in trips:
        data = load_prepared(path)
        selected = predict_indices(data, *models)
        _, stats = evaluate(selected, data["candidates"], data["reference"], data["route"],
                            data["arcs"], data["finite"], data["reset"])
        rows.append(dict(trip_id=path.stem, **stats))
    summary = dict(trips=len(rows), macro_f1=float(np.mean([r["macro_f1"] for r in rows])),
                   top1=sum(r["correct"] for r in rows) / sum(r["observations"] for r in rows))
    args.output.mkdir(exist_ok=True, parents=True)
    write_rows(args.output / "per_trip.csv", rows)
    (args.output / "summary.json").write_text(json.dumps(summary, indent=2)+"\n", encoding="utf-8")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
