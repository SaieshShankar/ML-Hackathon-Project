# PathSnap champion

**0.9065 student-test Macro F1 · 92.84% Top-1 · CPU only**

The selected model uses 51 LightGBM features and topology-aware Viterbi with learned transition scores. The classifier was fitted on all 80 training trips. The separate transition scorer used 78 trips after applying the 50 m alignment-quality filter. The selected configuration scored 0.8806 Macro F1 across the original five training folds.

## Start here

| File | What it does |
|---|---|
| `prepare.py` | Turns the original student ZIP into candidates, 51 features and derived labels. |
| `train.py` | Retrains the classifier on all 80 trips and fits the learned transition scorer. |
| `predict.py` | Predicts the arc for each observation in one trip. Uses GPS, nodes and arcs. |
| `evaluate.py` | Scores the bundled or retrained model on the prepared student-test trips. |
| `pathsnap/` | Candidate generation, training-label alignment, heading, context, graph, Viterbi and metrics. |
| `model/` | Verified native LightGBM weights, plain JSON transition parameters and training metadata. |
| `results/` | [Experiment report](results/REPORT.md), comparison and per-trip scores. |
| `Old Models/` | Earlier benchmark, original experiments, demos and working archives. |

## Reproduce the 10-trip student test

Run from this directory with Python 3.11. Supply your original copy of Student folder.zip.

```sh
python -m pip install -r requirements.txt
python prepare.py --dataset "Student folder.zip" --split student_test
python evaluate.py
```

The bundled weights reproduce all 19,160 saved predictions from the 0.9065 run. The reserved evaluator trips were outside that experiment.

## Predict a trip

```sh
python predict.py --track trip.track --nodes trip.nodes --arcs trip.arcs --output predictions.csv
```

The prediction path uses no reference route. Arc IDs are zero-based row indices in the trip's arc file. By default, prediction and evaluation use the bundled weights in model/.

## Retrain on CPU

```sh
python prepare.py --dataset "Student folder.zip"
python train.py --output trained-model
python evaluate.py --model trained-model
```

Retraining writes to trained-model by default, leaving the verified weights available. The 10 student-test trips are read by the evaluation command. The original configuration search is under [Old Models](Old%20Models/Integrated%20experiment%20sweep/source/README.md).
