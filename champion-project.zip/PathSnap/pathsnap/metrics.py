"""Metrics used in the verified integrated experiment."""
import numpy as np
from difflib import SequenceMatcher
from sklearn.metrics import f1_score


def dedup(road_ids):
    return road_ids[np.r_[True, road_ids[1:] != road_ids[:-1]]]


def evaluate(selected_idx, candidates, reference, route, arcs, finite, reset):
    prediction = candidates[np.arange(len(reference)), selected_idx]
    truth = prediction == reference
    contiguous = ((prediction[:-1] == prediction[1:]) |
                  (arcs[prediction[:-1], 1] == arcs[prediction[1:], 0]))
    bounded_connected = finite[np.arange(len(reference) - 1), selected_idx[:-1], selected_idx[1:]]
    macro = f1_score(reference, prediction, average="macro", zero_division=0)
    return prediction, dict(
        observations=len(reference), correct=int(truth.sum()), macro_f1=macro,
        top1=float(truth.mean()), direct_continuity=float(contiguous.mean()),
        bounded_graph_continuity=float(bounded_connected[~reset].mean()) if np.any(~reset) else "",
        reference_route_sequence_ratio=SequenceMatcher(
            None, dedup(route).tolist(), dedup(prediction).tolist(), autojunk=False).ratio(),
    )
