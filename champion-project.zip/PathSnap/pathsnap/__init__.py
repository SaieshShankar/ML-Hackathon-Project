"""PathSnap champion pipeline."""
